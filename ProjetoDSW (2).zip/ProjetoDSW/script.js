const contenedor = document.getElementById("test");
const botonRes = document.getElementById("boton");
const resultadoTest = document.getElementById("resultado");

const perguntas = [
  {
    pergunta: "1. De quem é a famosa frase 'Penso, logo existo'?",
    opções: {
        a: "Platão",
        b: "Galileu Galilei",
        c: "Descartes",
        d: "Francis Bacon"
    },
    respostaCorreta: "c",
  },
  {
    pergunta: "2. De onde é a invenção do chuveiro elétrico?",
    opções: {
      a: "França",
      b: "Inglaterra",
      c: "Brasil",
      d: "Austrália"
    },
    respostaCorreta: "c",
  },
  {
    pergunta: "3. Qual o livro mais vendido no mundo a seguir à Bíblia?",
    opções: {
      a:"O Senhor dos Anéis",
      b:"Dom Quixote",
      c:"O Pequeno Príncipe",
      d:"Ela, a Feiticeira"
    },
    respostaCorreta: "b",
  },
  {
    pergunta: "4. Atualmente, quantos elementos químicos a tabela periódica possui?",
    opções: {
      a: "113",
      b: "109",
      c: "108",
      d: "118"
    },
    respostaCorreta: "d",
  },
  {
    pergunta: "5. Qual o maior animal terrestre?",
    opções: {
      a: "Baleia Azul",
      b: "Dinossauro",
      c: "Elefante africano",
      d: "Girafa"
    },
    respostaCorreta: "c",
  },
  
];

function mostrarTest() {
  const perguntasYopções = [];

  perguntas.forEach((perguntaAtual, numeroDaPergunta) => {
    const opções = [];

    for (letraResposta in perguntaAtual.opções) {
      opções.push(
        `<label>
                  <input type="radio" name="${numeroDaPergunta}" value="${letraResposta}" />
                  ${letraResposta} : ${perguntaAtual.opções[letraResposta]}
              </label>`
      );
    }

    perguntasYopções.push(
      `<div class="cuestion">${perguntaAtual.pergunta}</div>
          <div class="opções"> ${opções.join("")} </div>
          `
    );
  });

  contenedor.innerHTML = perguntasYopções.join("");
}

mostrarTest();

function mostrarResultado() {
  const opções = contenedor.querySelectorAll(".opções");
  let respostasCorretas = 0;

  perguntas.forEach((perguntaAtual, numeroDaPergunta) => {
    const todasLasopções = opções[numeroDaPergunta];
    const checkboxopções = `input[name='${numeroDaPergunta}']:checked`;
    const respuestaElegida = (
      todasLasopções.querySelector(checkboxopções) || {}
    ).value;

    if (respuestaElegida === perguntaAtual.respostaCorreta) {
      respostasCorretas++;

      opções[numeroDaPergunta].style.color = "blue";
    } else {
      opções[numeroDaPergunta].style.color = "red";
    }
  });

  resultadoTest.innerHTML =
    "Usted ha acertado " +
    respostasCorretas +
    " perguntas de un total de " +
    perguntas.length;
}

botonRes.addEventListener("click", mostrarResultado);
